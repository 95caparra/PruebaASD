import { SidebarService } from './../../services/sidebar.service';
import { Component, OnInit } from '@angular/core';


@Component({
    selector: 'app-sidebar',
    templateUrl: 'sidebar.component.html',
})

export class SidebarComponent implements OnInit {
    public menuItems: any[];

    constructor( private sidebarService: SidebarService ) {
        this.menuItems = sidebarService.menu;
        console.log(this.menuItems)
    }

    ngOnInit() {
        
    }

        
}
