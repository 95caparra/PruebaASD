export class Ciudad {
    constructor(
        public id: number,
        public nombre: string
    ){}
}