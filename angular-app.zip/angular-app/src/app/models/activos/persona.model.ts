export class Persona {
    constructor(
        public id: number,
        public nombre: string
    ){}
}