import { Ciudad } from './ciudad.model';
export class Area {
    constructor(
        public id: number,
        public nombre: string,
        public ciudad: Ciudad
    ){}
}