import { Persona } from './persona.model';
import { Area } from './area.model';
import { Estado } from './estado.model';

export class Activo {
    constructor(
        public id: number,  
        public nombre: string,
        public descripcion: string,
        public tipo: string,
        public serial: string,
        public peso: number,
        public largo: number,
        public ancho: number,
        public valorCompra: number,
        public fechaCompra: string,
        public fechaBaja: string,
        public estado: Estado,
        public color: string,
        public area: Area,
        public persona: Persona,
        public numeroInterno: number
    ){}
}