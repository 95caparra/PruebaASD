import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateActivosComponent } from './create-activos.component';

describe('CreateActivosComponent', () => {
  let component: CreateActivosComponent;
  let fixture: ComponentFixture<CreateActivosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateActivosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateActivosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
