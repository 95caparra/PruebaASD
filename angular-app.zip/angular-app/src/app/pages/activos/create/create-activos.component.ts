import { Area } from './../../../models/activos/area.model';
import { Persona } from './../../../models/activos/persona.model';
import { Estado } from './../../../models/activos/estado.model';
import { ActivoService } from './../../../services/activo.service';
import { Activo } from './../../../models/activos/activo.model';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-create-activos',
  templateUrl: './create-activos.component.html',
  styleUrls: ['./create-activos.component.css']
})
export class CreateActivosComponent implements OnInit {

  public estados: Estado[] = [];
  public personas: Persona[] = [];
  public areas: Area[] = [];

  public estadoSeleccionado: Estado;
  public personaSeleccionada: Persona;
  public areaSeleccionada: Area;

  registerForm: FormGroup;
  private activo: Activo;
  submitted = false;

  constructor(
    private activoService: ActivoService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private fb: FormBuilder) { }

  ngOnInit(): void {

    this.cargarEstados();
    this.cargarPersonas();
    this.cargarAreas();

    this.registerForm = this.fb.group({
      nombre: ['', [Validators.required]],
      descripcion: ['', [Validators.required]],
      tipo: ['', [Validators.required]],
      serial: ['', [Validators.required]],
      peso: ['', [Validators.required, Validators.min]],
      largo: ['', [Validators.required]],
      ancho: ['', [Validators.required]],
      valorCompra: ['', [Validators.required]],
      fechaCompra: ['', [Validators.required]],
      fechaBaja: ['', [Validators.required]],
      estado: ['', [Validators.required]],
      color: ['', [Validators.required]],
      area: ['', [Validators.required]],
      persona: ['', [Validators.required]],
      numeroInterno: ['', [Validators.required]],
    }
    );

    this.registerForm.get('estado').valueChanges
      .subscribe(estadoId => {
        this.estadoSeleccionado = this.estados.find(e => e.id = estadoId);
      })

    this.registerForm.get('area').valueChanges
      .subscribe(areaId => {
        this.areaSeleccionada = this.areas.find(a => a.id = areaId);
      })

    this.registerForm.get('persona').valueChanges
      .subscribe(personaId => {
        this.personaSeleccionada = this.personas.find(p => p.id = personaId);
      })
  }

  // convenience getter for easy access to form fields
  get f() { return this.registerForm.controls; }

  onSubmit() {
    this.submitted = true;
    
    this.activo = this.registerForm.value;

    this.activo.persona = this.personaSeleccionada;
    this.activo.area = this.areaSeleccionada;
    this.activo.estado = this.estadoSeleccionado;

    
    this.activoService.crearActivo(this.activo)
      .subscribe((resp: any) => {
        console.log(resp);
        Swal.fire('Creado', `creado correctamente`, 'success');
        this.router.navigateByUrl('/activos');
      })
  }

  cargarEstados() {
    this.activoService.cargarEstados()
      .subscribe((estados: Estado[]) => {
        this.estados = estados;
      })
  }

  cargarPersonas() {
    this.activoService.cargarPersonas()
      .subscribe((personas: Persona[]) => {
        this.personas = personas;
      })
  }

  cargarAreas() {
    this.activoService.cargarAreas()
      .subscribe((areas: Area[]) => {
        this.areas = areas;
      })
  }

  onReset() {
    this.submitted = false;
    this.registerForm.reset();
    this.router.navigateByUrl('/activos');
  }

}
