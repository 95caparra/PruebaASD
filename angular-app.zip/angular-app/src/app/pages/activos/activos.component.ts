import { Router } from '@angular/router';
import { filter } from 'rxjs/operators';
import { ActivoService } from './../../services/activo.service';
import { Activo } from './../../models/activos/activo.model';
import { Component, OnInit } from '@angular/core';
import Swal from 'sweetalert2';
import {NgbCalendar, NgbDateAdapter, NgbDateParserFormatter, NgbDateStruct} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-activos',
  templateUrl: './activos.component.html',
  styleUrls: ['./activos.component.css']
})
export class ActivosComponent implements OnInit {

  public activos: Activo[] = [];
  public activo: Activo;
  public cargando: boolean = true;
  public total: number = 0;

  constructor(
    private activoService: ActivoService,
    private router: Router,
  ) {

  }

  ngOnInit(): void {
    this.cargarData();
  }

  cargarData() {
    this.cargando = true;
    this.activoService.cargarActivos()
      .subscribe((activos: Activo[]) => {
        this.activos = activos;
        this.total = this.activos.length;
        this.cargando = false;
      })
  }

  buscarTermino(termino: string) {
    this.activos = [];
    this.cargando = true;
    this.activoService.cargarActivosPorTermino(termino)
      .subscribe((activos: Activo[]) => {
        this.activos = activos;
        this.total = this.activos.length;        
        this.cargando = false;
      })
  }

  buscarTipo(termino: string) {
    this.activos = [];
    this.cargando = true;
    this.activoService.cargarActivosPorTipo(termino)
      .subscribe((activos: Activo[]) => {
        this.activos = activos;
        this.total = this.activos.length;        
        this.cargando = false;
      })
  }

  buscarSerial(termino: string) {
    this.activos = [];
    this.cargando = true;
    this.activoService.cargarActivosPorSerial(termino)
      .subscribe((activo: Activo) => {
        this.activo = activo;
        this.activos.push(this.activo);
        this.total = this.activos.length;        
        this.cargando = false;
      })
  }

  buscarFechaCompra(termino: string) {
    this.activos = [];
    this.cargando = true;
    this.activoService.cargarActivosPorFecha(termino)
      .subscribe((activos: Activo[]) => {
        this.activos = activos;
        this.total = this.activos.length;        
        this.cargando = false;
      })
  }

  cambiarPagina(valor: number) {

  }

  async guardarCambios(act: Activo) {
    console.log(act);
    this.activoService.actualizarActivo(act.id, act)
      .subscribe(resp => {       
        Swal.fire('Actualizado', 'success');
        this.router.navigateByUrl('/activos');
      });    
  }


}
