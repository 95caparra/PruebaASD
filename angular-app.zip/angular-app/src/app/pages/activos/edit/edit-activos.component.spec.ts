import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditActivosComponent } from './edit-activos.component';

describe('EditActivosComponent', () => {
  let component: EditActivosComponent;
  let fixture: ComponentFixture<EditActivosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditActivosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditActivosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
