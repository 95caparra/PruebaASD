import { Area } from './../../models/activos/area.model';
import { Component, OnInit } from '@angular/core';
import Swal from 'sweetalert2';
import { ActivoService } from 'src/app/services/activo.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-areas',
  templateUrl: './areas.component.html',
  styleUrls: ['./areas.component.css']
})
export class AreasComponent implements OnInit {

  public areas: Area[] = [];
  public area: Area;
  public cargando: boolean = true;
  public total: number = 0;

  constructor(
    private activoService: ActivoService,
    private router: Router,
  ) {

  }

  ngOnInit(): void {
    this.cargarData();
  }

  cargarData() {
    this.cargando = true;
    this.activoService.cargarAreas()
      .subscribe((areas: Area[]) => {
        this.areas = areas;
        this.total = this.areas.length;
        this.cargando = false;
      })
  }

 
  cambiarPagina(valor: number) {

  }


}