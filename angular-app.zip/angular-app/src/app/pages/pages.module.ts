import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { PagesComponent } from './pages.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
// Modulos
import { SharedModule } from '../shared/shared.module';
import { PagesRoutingModule } from './pages-routing.module';
import { MatDatepickerModule } from '@angular/material/datepicker';

//Components
import { DashboardComponent } from './dashboard/dashboard.component';
import { ActivosComponent } from './activos/activos.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatMomentDateModule, MomentDateAdapter } from "@angular/material-moment-adapter";
import { CreateActivosComponent } from './activos/create/create-activos.component';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from "@angular/material/form-field";
import { EditActivosComponent } from './activos/edit/edit-activos.component';
import { AreasComponent } from './areas/areas.component';




@NgModule({
  declarations: [
    PagesComponent, 
    DashboardComponent, 
    ActivosComponent,
    CreateActivosComponent,
    EditActivosComponent,
    AreasComponent
  ],
  exports: [
    PagesComponent, 
    DashboardComponent, 
    ActivosComponent,
    CreateActivosComponent,
    EditActivosComponent,
    AreasComponent
  ],
  imports: [
    CommonModule,
    PagesRoutingModule,
    SharedModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    BrowserAnimationsModule,
    MatDatepickerModule,
    MatMomentDateModule,
  ]
})
export class PagesModule { }
