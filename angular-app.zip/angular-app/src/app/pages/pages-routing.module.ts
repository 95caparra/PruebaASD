import { AreasComponent } from './areas/areas.component';
import { EditActivosComponent } from './activos/edit/edit-activos.component';
import { ActivosComponent } from './activos/activos.component';

import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PagesComponent } from './pages.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { CreateActivosComponent } from './activos/create/create-activos.component';

const routes: Routes = [
  { 
      path: '', 
      component: PagesComponent,
      children: [
          { path: '', component: DashboardComponent, data: { titulo: 'Dashboard' } },
          { path: 'activos', component: ActivosComponent, data: { titulo: 'Activos' } },
          { path: 'create-activos', component: CreateActivosComponent, data: { titulo: 'Crear Activos' } },
          { path: 'edit-activos/:id', component: EditActivosComponent, data: { titulo: 'Crear Activos' } },
          { path: 'areas', component: AreasComponent, data: { titulo: 'Áreas' } },
      ]
  },
];

@NgModule({
  imports: [ RouterModule.forChild(routes) ],
  exports: [ RouterModule ]
})
export class PagesRoutingModule {}
