import { Persona } from './../models/activos/persona.model';
import { Area } from './../models/activos/area.model';
import { Estado } from './../models/activos/estado.model';
import { Activo } from './../models/activos/activo.model';

import { Injectable, NgZone } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Observable, of, throwError } from 'rxjs';
import { tap, map, catchError } from 'rxjs/operators';

import { environment } from '../../environments/environment';
import Swal from 'sweetalert2';

const base_url = environment.base_url;
@Injectable({
    providedIn: 'root'
})

export class ActivoService {

    public Activo: Activo;

    constructor(private http: HttpClient) { }

    cargarActivos() {
        const url = `${base_url}/activos`;
        return this.http.get(url)
            .pipe(
                map((response: Activo[]) => response)
            );
    }

    cargarActivosPorId(id: number) {
        const url = `${base_url}/activos/${id}`;
        return this.http.get(url)
            .pipe(
                map((response: any) => response.objeto)
            );
    }

    cargarEstados() {
        const url = `${base_url}/activos/estados`;
        return this.http.get(url)
            .pipe(
                map((response: Estado[]) => response)
            );
    }

    cargarAreas() {
        const url = `${base_url}/activos/areas`;
        return this.http.get(url)
            .pipe(
                map((response: Area[]) => response)
            );
    }

    cargarPersonas() {
        const url = `${base_url}/activos/personas`;
        return this.http.get(url)
            .pipe(
                map((response: Persona[]) => response)
            );
    }

    cargarActivosPorTermino(termino: string) {
        const url = `${base_url}/activos/termino/${termino}`;
        return this.http.get(url)
            .pipe(
                map((response: any) => response.objeto)
            );
    }

    cargarActivosPorTipo(tipo: string) {
        const url = `${base_url}/activos/tipo/${tipo}`;
        return this.http.get(url)
            .pipe(
                map((response: any) => response.objeto)
            );
    }

    cargarActivosPorSerial(serial: string) {
        const url = `${base_url}/activos/serial/${serial}`;
        return this.http.get(url)
            .pipe(
                map((response: any) => response.objeto)
            );
    }

    cargarActivosPorFecha(fecha: string) {
        const url = `${base_url}/activos/fechaCompra/${fecha}`;
        return this.http.get(url)
            .pipe(
                map((response: any) => response.objeto)
            );
    }


    crearActivo(objeto: Activo) {

        let headers = new HttpHeaders();
        headers.append("Accept", "application/json");
        headers.append("Content-Type", "application/json");

        const url = `${base_url}/activos`;
        return this.http.post(url, objeto, {headers: headers }).pipe(
            catchError(e => {
                if (e.status == 400) {
                    return throwError(e);
                }
                console.error(e.error.message);
                Swal.fire(e.error.message, e.error.error, 'error');
                return throwError(e);
            })
        );
    }


    actualizarActivo(_id: number, objeto: Activo) {
        let headers = new HttpHeaders();
        headers.append("Accept", "application/json");
        headers.append("Content-Type", "application/json");

        const url = `${base_url}/activos/${_id}`;
        return this.http.put(url, objeto, {headers: headers }).pipe(
            catchError(e => {
                if (e.status == 400) {
                    return throwError(e);
                }
                console.error(e.error.message);
                Swal.fire(e.error.message, e.error.error, 'error');
                return throwError(e);
            })


        );
    }

}
